<?php

   require_once ('Usuario.php');
   
   for ($i=0; $i < count($ArrayUsuarios); $i++) {
      if (@$_POST['mail']==$ArrayUsuarios[$i]->getMail() && @$_POST['password']==$ArrayUsuarios[$i]->getPassword()){
         $nombre=$ArrayUsuarios[$i]->getNombre();
         header("Location:Bienvenido.php?nombre=$nombre");
         break;
      }else {
         header("Location:index.php?error=true");
      }
   }
?> 