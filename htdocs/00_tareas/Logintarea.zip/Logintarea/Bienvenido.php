<!DOCTYPE html>
<html lang="en">
<?php
    require_once ('Usuario.php');

    $nombreUsuario=$_GET['nombre'];
    $ArrayUsuarios;
    $arrayhobbie;

    for ($i=0; $i < count($ArrayUsuarios) ; $i++) { 
        if ($nombreUsuario==$ArrayUsuarios[$i]->getNombre()) {
            $arrayhobbie=$ArrayUsuarios[$i]->getHobbies();
        
        }
    }
?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Bienvenido.css">
    <title>Bienvenido</title>
</head>
<body>
    <div id="contenedor">
        <h1>Bienvenido <?=$nombreUsuario?> </h1>
        <ul id="lista">
            <?php
                for ($i=0; $i < count($arrayhobbie) ; $i++) { 
                    $h=$arrayhobbie[$i];
                    echo "<li class='elemtoLista'>$h</li>";
                }
            ?>
        </ul>
        <a id='cerrarSesion'href='index.php'>Cerrar Sesion</a>
    </div>
</body>
</html>