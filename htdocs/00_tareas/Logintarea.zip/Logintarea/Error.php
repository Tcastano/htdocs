<?php
echo "<div id='diverror'><p>Usuario y/o contraseña incorrectos.Intentelo de nuevo</p></div>";
?>